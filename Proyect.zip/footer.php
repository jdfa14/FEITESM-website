<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 copyright">
				FEITESM 2015
			</div>
			<div class="col-sm-6 menu">
				<ul>
					<li>
					<a href="#">CAM</a>
				</li>
				<li>
					<a href="../CARE/principalCARE.html">CARE</a>
				</li>
				<li>
					<a href="../CCE/principalCCE.html">CCE</a>
				</li>
				<li>
					<a href="../CEF/principalCEF.html">CEF</a>
				</li>
				<li>
					<a href="../CSA/principalCSA.html">CSA</a>
				</li>
				<li>
					<a href="../contactus.html">Contacto</a>
				</li>
				</ul>
			</div>
			<div class="col-sm-3 social">
				<a href="http://www.facebook.com/feitesm.mty" target="_blank">
					<img src="/feitesm-website/images/social/social-fb.png" alt="facebook" />
				</a>
				<a href="http://www.twitter.com/feitesm_mty" target="_blank">
					<img src="/feitesm-website/images/social/social-tw.png" alt="twitter" />
				</a>					
			</div>
		</div>
	</div>
</div>