<div class="container head">
	<div class="navbar-header">
		<a href="/feitesm-website/index.php" class="navbar-brand">FEITESM</a>
	</div>
	<div class="sidebar-toggle">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</div>
</div>