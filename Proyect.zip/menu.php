<header class="navbar navbar-inverse normal" role="banner">
	<div class="container">
		<div class="navbar-header">
			<a href="../index.html" class="navbar-brand">FEITESM</a>
		</div>
		<div class="sidebar-toggle">
			<div class="line"></div>
			<div class="line"></div>
			<div class="line"></div>
		</div>
	</div>
</header>